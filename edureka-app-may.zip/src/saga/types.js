export const GET_COURSES = 'GET_COURSES';
export const ADD_ENQUIRY = 'ADD_ENQUIRY';
export const GET_ENQUIRY = 'GET_ENQUIRY';